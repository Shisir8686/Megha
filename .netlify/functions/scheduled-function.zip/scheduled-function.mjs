
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/scheduled-function/scheduled-function.mjs
var scheduled_function_default = async (req) => {
  const { next_run } = await req.json();
  console.log("Received event! Next invocation at:", next_run);
};
var config = {
  schedule: "@hourly"
};
export {
  config,
  scheduled_function_default as default
};
